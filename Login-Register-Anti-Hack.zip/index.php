<!DOCTYPE html>
<html lang="en">
<head>
    <!-- code antihack by d4ff4 AutoXploCode -->
    <!-- Author Petanikode.com  -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>AutoXploCode</title>

     <link rel="stylesheet" href="css/bootstrap.min.css" />
</head>
<body class="bg-light" oncopy='return false' oncut='return false' onpaste='return false'>
    <header>
        <div class="jumbotron jumbotron-fluid">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <h1>Selamat Datang Di AutoXploCode Member Login</h1>
                        <p>developer Website: autoxplocode</p>
                    </div>
                    <div class="col-md-4">
                        <a href="login.php" class="btn btn-secondary">Masuk</a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <section>
        <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <img class="img img-responsive" src="https://i.ibb.co/0f8WrgN/Whats-App-Image-2020-04-09-at-22-10-51.jpg" />
                    </div>
                </div>
            </div>
    </section>

</body>
</html>